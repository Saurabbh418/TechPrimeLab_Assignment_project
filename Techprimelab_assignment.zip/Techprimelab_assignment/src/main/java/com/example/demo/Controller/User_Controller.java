package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.example.demo.Model.User;
import com.example.demo.Repositary.User_Repositary;
import jakarta.servlet.http.HttpSession;

@Controller
public class User_Controller {
	
	@Autowired
	private User_Repositary userrepo;
	
	@RequestMapping("/")
	public String home() {
		return "login";
	}
	
	@RequestMapping("/adduser")
	public String addUser(@ModelAttribute User user) {
		userrepo.save(user);
		return "login";
	}
	
	@RequestMapping("/getdata")
	public String getdata(Model m) {

		List<User> userall = userrepo.findAll();
		m.addAttribute("getuserdata", userall);
		return "Listofuser";
	}
	
	@RequestMapping("/{id}")
	public String deleteuser(@PathVariable int id) {

		userrepo.deleteById(id);

		return "redirect:/getdata";

	}
	
	@RequestMapping("/edit/{id}")
	public String editform(@PathVariable int id, Model m) {
		User ob = userrepo.findById(id).get();

		m.addAttribute("std1", ob);
		return "UpdateUser";
	}
	
	@RequestMapping("/update/{id}")
	public String updatedata(@PathVariable int id, @ModelAttribute User us) {
		User user = userrepo.findById(id).orElse(null);

		if (user != null) {
			user.setName(us.getName());
			user.setEmail(us.getEmail());
			user.setPassword(us.getPassword());

			userrepo.save(user);
		}
		return "redirect:/getdata";
	}
	
	@RequestMapping("/login")
	public String login(@RequestParam String email, @RequestParam String password, HttpSession login) {
		User user = userrepo.findByemail(email);

		if (user != null && user.getEmail().equals(email) && user.getPassword().equals(password)) {

			login.setAttribute("login", user);
			return "redirect:/getprojectdata";

		} else {

			return "login";
		}

	}

}
