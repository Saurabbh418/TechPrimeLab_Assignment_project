package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.Model.Project;
import com.example.demo.Repositary.Project_Repositary;

@Controller
public class Project_Controller {
	
	@Autowired
	private Project_Repositary projectrepo;
	
	@RequestMapping("/addproject")
	public String addProject(@ModelAttribute Project project) {
		
		projectrepo.save(project);
		return "redirect:/getprojectdata";
	}
	
	@RequestMapping("/getprojectdata")
	public String getProject(Model m) {
		
		List<Project> allproject = projectrepo.findAll();
		m.addAttribute("getprojectdata", allproject);
		
		return "Listofproject";
	}
	
	@RequestMapping("/delete/{id}")
	public String deleteproject(@PathVariable int id) {
		projectrepo.deleteById(id);
		return "redirect:/getprojectdata";
	}
	
	@RequestMapping("/editproject/{id}")
	public String editform(@PathVariable int id,Model m) {
		Project project =projectrepo.findById(id).get();
		m.addAttribute("updateproject", project);
		return "UpdateProject";
	}
	
	@RequestMapping("/updateproject/{id}")
	public String updateproject(@PathVariable int id,@ModelAttribute Project pro) {
		
		Project project = projectrepo.findById(id).orElse(null);
		
		if (project != null) {
			project.setName(pro.getName());
			project.setReason(pro.getReason());
			project.setType(pro.getType());
			project.setDivision(pro.getDivision());
			project.setCategory(pro.getCategory());
			project.setPriority(pro.getPriority());
			project.setDept(pro.getDept());
			project.setLocation(pro.getLocation());
			
			
			projectrepo.save(project);
		}
		return "redirect:/getprojectdata";
	}
	
	@RequestMapping("/start/{id}")
	public String updatestartstatus(@PathVariable int id) {
		Project project = projectrepo.findById(id).orElse(null);
		
		project.setStatus("Running");
		projectrepo.save(project);
		return "redirect:/getprojectdata";
		
	}
	
	@RequestMapping("/close/{id}")
	public String updateclosestatus(@PathVariable int id) {
		Project project = projectrepo.findById(id).orElse(null);
		
		project.setStatus("Closed");
		projectrepo.save(project);
		return "redirect:/getprojectdata";
		
	}
	
	@RequestMapping("/cancel/{id}")
	public String updatecancelstatus(@PathVariable int id) {
		Project project = projectrepo.findById(id).orElse(null);
		
		project.setStatus("Cancelled");
		projectrepo.save(project);
		return "redirect:/getprojectdata";
		
	}
}
