package com.example.demo.Repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Model.Project;

public interface Project_Repositary extends JpaRepository<Project, Integer>{

}
