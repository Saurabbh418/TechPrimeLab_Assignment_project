package com.example.demo.Repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Model.User;

public interface User_Repositary extends JpaRepository<User, Integer>{

	public User findByemail(String email);
}
